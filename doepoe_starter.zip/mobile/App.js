import React, { useEffect, useState } from 'react';
import { Text, View, FlatList, Button, ActivityIndicator } from 'react-native';
import axios from 'axios';
import { StatusBar } from 'expo-status-bar';

export default function App() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get('https://<YOUR_REPLIT_URL>.repl.co/products')
      .then(res => {
        setProducts(res.data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  const addToCart = (item) => {
    setCart([...cart, item]);
  };

  const submitOrder = () => {
    axios.post('https://<YOUR_REPLIT_URL>.repl.co/order', { items: cart })
      .then(() => setCart([]))
      .catch(err => console.error(err));
  };

  if (loading) {
    return <ActivityIndicator size="large" style={{ flex: 1, justifyContent: 'center' }} />;
  }

  return (
    <View style={{ flex: 1, padding: 24 }}>
      <FlatList
        data={products}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={{ marginBottom: 16 }}>
            <Text>{item.name} - ₹{item.price}</Text>
            <Button title="Add to Cart" onPress={() => addToCart(item)} />
          </View>
        )}
      />
      {cart.length > 0 && (
        <Button title="Checkout" onPress={submitOrder} />
      )}
      <StatusBar style="auto" />
    </View>
  );
}
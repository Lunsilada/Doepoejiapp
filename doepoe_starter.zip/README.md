
# Doepoe Starter Project

This repository contains a minimal e‑commerce starter for **Doepoe** with:

* **Backend**: Node.js + Express (Replit-ready)  
* **Mobile App**: React Native (Expo)  
* **Features**:
  * Email login placeholder (Firebase integration to be added)
  * Product list fetched from backend
  * Simple cart + checkout flow
  * Offline-friendly by default (Expo assets / can add AsyncStorage)
  * Push notifications and Firebase setup stubs
  * Categories like “Under ₹9”, “Under ₹19”, etc. (add logic as needed)

## Quick Start (from iPhone)

1. **Backend**
   * Open this project in Replit
   * In the `backend` folder, click **Run** to start the API  
   * Note the public URL (something like `https://your‑replit-url.repl.co`)

2. **Mobile App**
   * Install **Expo Go** from the App Store / Play Store
   * In Replit, open the `mobile` folder
   * Click **Run** → Replit shows a QR code  
   * Scan QR code with **Expo Go** → App loads on your phone

3. **Connect Mobile to Backend**
   * Edit `mobile/App.js`
   * Replace `<YOUR_REPLIT_URL>` with your actual Replit backend URL

## Next Steps

* Add Firebase config in `mobile/firebase.js` for email login + push notifications
* Implement price filters (Under ₹9 etc.) in the mobile app
* Replace placeholder assets in `mobile/assets`
* Secure backend routes and deploy on Railway / Render if desired

import express, { json } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import products from './products.json' assert { type: 'json' };

dotenv.config();
const app = express();
app.use(cors());
app.use(json());

app.get('/products', (req, res) => {
  res.json(products);
});

app.post('/order', (req, res) => {
  console.log('Order received:', req.body);
  // Here you can add logic to notify admin or store order
  res.json({ status: 'ok', message: 'Order placed successfully' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('Backend listening on port', PORT));